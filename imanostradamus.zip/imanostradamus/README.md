# IMANOSTRADAMUS

Full-stack immersive portfolio + service platform.

## Features

- High-performance WebGL particle network hero (Three.js)
- Energy beams leading to three services
- Professional multi-step service request form
- Google AI (Gemini) chatbot with female voice (browser SpeechSynthesis)
- Firebase-ready lead storage
- Ready for Vercel deployment

## Quick Start

```bash
npm install
cp .env.example .env.local
# Add your GOOGLE_AI_API_KEY and Firebase keys
npm run dev
```

## Environment Variables

See `.env.example`

Required for chatbot:
- `GOOGLE_AI_API_KEY` → from Google AI Studio

Optional (leads saved to Firestore):
- Firebase web config keys

## Deploy to Vercel

1. Push this folder to a GitHub repo
2. Import the repo in Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

## Structure

- `src/components/ParticleHero.tsx` — WebGL particle + beams system
- `src/components/ServiceNodes.tsx` — Left service portals
- `src/components/ServiceForm.tsx` — Multi-step request form
- `src/components/AIChat.tsx` — Floating AI + voice
- `src/app/api/chat` — Gemini backend
- `src/app/api/lead` — Form submissions

Built for performance and visual impact.
