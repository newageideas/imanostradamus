import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Basic validation
    if (!body.email || !body.businessName || !body.service) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Try Firebase if configured
    const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
    if (projectId && process.env.NEXT_PUBLIC_FIREBASE_API_KEY) {
      try {
        const { db } = await import("@/lib/firebase");
        const { collection, addDoc } = await import("firebase/firestore");
        await addDoc(collection(db, "leads"), {
          ...body,
          status: "new",
          createdAt: new Date().toISOString(),
        });
      } catch (fbErr) {
        console.warn("Firebase write failed, continuing:", fbErr);
      }
    }

    // Always log for visibility during development
    console.log("[LEAD]", JSON.stringify(body, null, 2));

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
