import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest, NextResponse } from "next/server";

const SYSTEM = `You are the intelligent voice of Imanostradamus — a full-stack builder who creates:
1. Websites + AI Voice agents (bilingual ordering, booking, customer support)
2. Apps that save money (automation, internal tools, cost-cutting systems)
3. Commercial ads (cinematic video content for local businesses)

Tone: confident, clear, helpful, slightly cosmic/high-frequency but still practical. Keep answers short and useful. You know he works with local restaurants and businesses in the Central Valley (California). Guide people toward requesting a service if they are interested. Never invent fake case studies.`;

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();
    const key = process.env.GOOGLE_AI_API_KEY;

    if (!key) {
      return NextResponse.json({
        reply:
          "The AI key is not configured yet. You can still use the service request form on the left to reach Imanostradamus directly.",
      });
    }

    const genAI = new GoogleGenerativeAI(key);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const history = messages
      .slice(0, -1)
      .map((m: { role: string; content: string }) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      }));

    const chat = model.startChat({
      history: [
        { role: "user", parts: [{ text: SYSTEM }] },
        {
          role: "model",
          parts: [
            {
              text: "Understood. I am the voice of Imanostradamus. Ready to help.",
            },
          ],
        },
        ...history,
      ],
    });

    const last = messages[messages.length - 1]?.content || "";
    const result = await chat.sendMessage(last);
    const reply = result.response.text();

    return NextResponse.json({ reply });
  } catch (err: any) {
    console.error("Chat error:", err);
    return NextResponse.json(
      { reply: "I hit a temporary issue. Try again or use the form." },
      { status: 200 }
    );
  }
}
