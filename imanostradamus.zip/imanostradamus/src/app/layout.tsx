import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "IMANOSTRADAMUS | Websites + Voice · Apps · Commercials",
  description:
    "Full-stack systems. Intelligent websites with AI voice, money-saving apps, and cinematic commercials. Built to make businesses move faster.",
  keywords: ["Imanostradamus", "AI websites", "voice agents", "apps", "commercials", "Central Valley"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full antialiased bg-[#030014] text-[#f4f0ff]">
        {children}
      </body>
    </html>
  );
}
