"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import ParticleHero from "@/components/ParticleHero";
import ServiceNodes from "@/components/ServiceNodes";
import ServiceForm from "@/components/ServiceForm";
import AIChat from "@/components/AIChat";

export default function Home() {
  const [activeService, setActiveService] = useState<string | null>(null);

  return (
    <main className="relative min-h-screen w-full overflow-hidden">
      {/* 3D Particle Network Background */}
      <ParticleHero />

      {/* Overlay content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Top bar */}
        <header className="flex items-center justify-between px-6 md:px-10 pt-6">
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-sm tracking-[0.35em] uppercase text-white/70"
          >
            Imanostradamus
          </motion.div>
          <motion.a
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            href="mailto:hello@imanostradamus.com"
            className="text-sm text-white/50 hover:text-purple-300 transition"
          >
            Contact
          </motion.a>
        </header>

        {/* Center title */}
        <div className="flex-1 flex flex-col items-center justify-center pointer-events-none px-4">
          <motion.h1
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.9 }}
            className="text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-center"
          >
            <span className="bg-gradient-to-b from-white via-purple-100 to-purple-400 bg-clip-text text-transparent">
              IMANOSTRADAMUS
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="mt-4 text-center text-white/55 max-w-md text-sm md:text-base tracking-wide"
          >
            Full-stack systems. Voice. Apps. Commercials.
            <br />
            Built to make businesses move faster.
          </motion.p>
        </div>

        {/* Service nodes on the left */}
        <ServiceNodes onSelect={(id) => setActiveService(id)} />

        {/* Bottom hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="pb-8 text-center text-xs text-white/30 tracking-widest uppercase"
        >
          Select a service · or talk to the AI
        </motion.div>
      </div>

      {/* Service request modal */}
      {activeService && (
        <ServiceForm
          service={activeService}
          onClose={() => setActiveService(null)}
        />
      )}

      {/* Floating AI chatbot */}
      <AIChat />
    </main>
  );
}
