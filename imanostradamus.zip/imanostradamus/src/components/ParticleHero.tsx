"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

interface ParticleHeroProps {
  onServiceClick?: (service: string) => void;
}

export default function ParticleHero({ onServiceClick }: ParticleHeroProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Quality based on device
    const isMobile = width < 768;
    const particleCount = isMobile ? 2800 : 6500;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030014, 0.035);

    const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 100);
    camera.position.set(0, 0, 14);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isMobile,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1.5 : 2));
    renderer.setSize(width, height);
    renderer.setClearColor(0x030014, 1);
    container.appendChild(renderer.domElement);

    // ========== PARTICLES ==========
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);
    const phases = new Float32Array(particleCount);

    const color1 = new THREE.Color("#a855f7");
    const color2 = new THREE.Color("#c084fc");
    const color3 = new THREE.Color("#e9d5ff");

    for (let i = 0; i < particleCount; i++) {
      const r = 4 + Math.random() * 18;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.7;
      positions[i * 3 + 2] = r * Math.cos(phi) - 4;

      const mix = Math.random();
      const c = mix < 0.5 ? color1.clone().lerp(color2, mix * 2) : color2.clone().lerp(color3, (mix - 0.5) * 2);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;

      sizes[i] = Math.random() * 2.5 + 0.6;
      phases[i] = Math.random() * Math.PI * 2;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.setAttribute("aSize", new THREE.BufferAttribute(sizes, 1));
    geo.setAttribute("aPhase", new THREE.BufferAttribute(phases, 1));

    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexColors: true,
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
      },
      vertexShader: `
        attribute float aSize;
        attribute float aPhase;
        uniform float uTime;
        uniform float uPixelRatio;
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          vColor = color;
          vec3 pos = position;
          pos.x += sin(uTime * 0.15 + aPhase) * 0.35;
          pos.y += cos(uTime * 0.12 + aPhase * 1.3) * 0.25;
          vec4 mv = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * uPixelRatio * (180.0 / -mv.z);
          vAlpha = 0.55 + 0.45 * sin(uTime * 1.2 + aPhase);
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          vec2 c = gl_PointCoord - 0.5;
          float d = length(c);
          if (d > 0.5) discard;
          float soft = smoothstep(0.5, 0.0, d);
          gl_FragColor = vec4(vColor, soft * vAlpha * 0.9);
        }
      `,
    });

    const points = new THREE.Points(geo, mat);
    scene.add(points);

    // ========== CENTRAL CORE ==========
    const coreGeo = new THREE.SphereGeometry(0.55, 32, 32);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      transparent: true,
      opacity: 0.95,
    });
    const core = new THREE.Mesh(coreGeo, coreMat);
    scene.add(core);

    // Outer glow ring
    const ringGeo = new THREE.RingGeometry(0.85, 1.15, 64);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xc084fc,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    scene.add(ring);

    // ========== ENERGY BEAMS ==========
    const beamGroup = new THREE.Group();
    scene.add(beamGroup);

    const beamData = [
      { angle: -0.55, label: "websites", color: 0xa855f7 },
      { angle: 0.0, label: "apps", color: 0xc084fc },
      { angle: 0.55, label: "commercials", color: 0xe9d5ff },
    ];

    const beams: THREE.Mesh[] = [];

    beamData.forEach((b) => {
      const beamGeo = new THREE.CylinderGeometry(0.04, 0.28, 9, 16, 1, true);
      beamGeo.translate(0, -4.5, 0);
      const beamMat = new THREE.MeshBasicMaterial({
        color: b.color,
        transparent: true,
        opacity: 0.45,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.rotation.z = b.angle;
      beam.position.set(0, 0.2, 0);
      beam.userData = { label: b.label };
      beamGroup.add(beam);
      beams.push(beam);
    });

    // ========== LIGHTS ==========
    const ambient = new THREE.AmbientLight(0x2e1065, 0.6);
    scene.add(ambient);
    const key = new THREE.PointLight(0xa855f7, 2.5, 30);
    key.position.set(0, 0, 4);
    scene.add(key);

    // ========== MOUSE ==========
    let mouseX = 0;
    let mouseY = 0;
    const onMove = (e: MouseEvent) => {
      mouseX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener("mousemove", onMove, { passive: true });

    // ========== RESIZE ==========
    const onResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    // ========== ANIMATION ==========
    const clock = new THREE.Clock();
    const animate = () => {
      const t = clock.getElapsedTime();
      mat.uniforms.uTime.value = t;

      // Core pulse
      const pulse = 1 + Math.sin(t * 2.2) * 0.08;
      core.scale.setScalar(pulse);
      ring.rotation.z = t * 0.15;
      ring.material.opacity = 0.25 + Math.sin(t * 1.8) * 0.12;

      // Slow camera drift
      camera.position.x += (mouseX * 1.2 - camera.position.x) * 0.03;
      camera.position.y += (mouseY * 0.8 - camera.position.y) * 0.03;
      camera.lookAt(0, 0, 0);

      // Gentle beam pulse
      beams.forEach((beam, i) => {
        const opacity = 0.35 + Math.sin(t * 1.5 + i) * 0.12;
        (beam.material as THREE.MeshBasicMaterial).opacity = opacity;
      });

      points.rotation.y = t * 0.02;

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };
    animate();

    // Cleanup
    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("resize", onResize);
      geo.dispose();
      mat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      ringGeo.dispose();
      (ring.material as THREE.Material).dispose();
      beams.forEach((b) => {
        b.geometry.dispose();
        (b.material as THREE.Material).dispose();
      });
      renderer.dispose();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full"
      style={{ zIndex: 0 }}
    />
  );
}
