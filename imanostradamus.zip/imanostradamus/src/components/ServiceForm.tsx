"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send, CheckCircle2 } from "lucide-react";

const serviceLabels: Record<string, string> = {
  websites: "Websites + AI Voice",
  apps: "Apps that Save Money",
  commercials: "Commercial Ads",
};

interface ServiceFormProps {
  service: string;
  onClose: () => void;
}

export default function ServiceForm({ service, onClose }: ServiceFormProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    businessName: "",
    contactName: "",
    email: "",
    phone: "",
    website: "",
    budget: "",
    timeline: "",
    description: "",
    goals: "",
  });

  const update = (key: string, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const submit = async () => {
    setLoading(true);
    try {
      await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          service,
          createdAt: new Date().toISOString(),
        }),
      });
      setDone(true);
    } catch (e) {
      console.error(e);
      alert("Something went wrong. Please try again or message me directly.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      >
        <motion.div
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.92, opacity: 0 }}
          className="glass w-full max-w-lg rounded-3xl p-6 md:p-8 relative max-h-[90vh] overflow-y-auto"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/50 hover:text-white transition"
          >
            <X size={22} />
          </button>

          {done ? (
            <div className="text-center py-10">
              <CheckCircle2 className="mx-auto text-purple-400 mb-4" size={48} />
              <h3 className="text-2xl font-semibold mb-2">Request received</h3>
              <p className="text-white/60">
                I’ll review it and get back to you shortly.
              </p>
              <button
                onClick={onClose}
                className="mt-6 px-6 py-2.5 rounded-full bg-purple-600 hover:bg-purple-500 transition"
              >
                Close
              </button>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <div className="text-xs uppercase tracking-[0.2em] text-purple-300/80">
                  Service Request
                </div>
                <h2 className="text-2xl font-semibold mt-1">
                  {serviceLabels[service] || service}
                </h2>
                <div className="flex gap-2 mt-3">
                  {[1, 2, 3].map((s) => (
                    <div
                      key={s}
                      className={`h-1 flex-1 rounded-full ${
                        step >= s ? "bg-purple-500" : "bg-white/10"
                      }`}
                    />
                  ))}
                </div>
              </div>

              {step === 1 && (
                <div className="space-y-4">
                  <Field
                    label="Business Name *"
                    value={form.businessName}
                    onChange={(v) => update("businessName", v)}
                    placeholder="e.g. Mayrita’s Mexican Restaurant"
                  />
                  <Field
                    label="Your Name *"
                    value={form.contactName}
                    onChange={(v) => update("contactName", v)}
                    placeholder="Full name"
                  />
                  <Field
                    label="Email *"
                    type="email"
                    value={form.email}
                    onChange={(v) => update("email", v)}
                    placeholder="you@business.com"
                  />
                  <Field
                    label="Phone"
                    value={form.phone}
                    onChange={(v) => update("phone", v)}
                    placeholder="(209) 555-0123"
                  />
                  <button
                    onClick={() => setStep(2)}
                    disabled={!form.businessName || !form.contactName || !form.email}
                    className="w-full mt-2 py-3 rounded-full bg-purple-600 hover:bg-purple-500 disabled:opacity-40 transition font-medium"
                  >
                    Continue
                  </button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <Field
                    label="Current Website (if any)"
                    value={form.website}
                    onChange={(v) => update("website", v)}
                    placeholder="https://"
                  />
                  <div>
                    <label className="text-sm text-white/70 mb-1.5 block">
                      Approximate Budget
                    </label>
                    <select
                      value={form.budget}
                      onChange={(e) => update("budget", e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-purple-500"
                    >
                      <option value="">Select range</option>
                      <option value="under-1k">Under $1,000</option>
                      <option value="1k-3k">$1,000 – $3,000</option>
                      <option value="3k-7k">$3,000 – $7,000</option>
                      <option value="7k-plus">$7,000+</option>
                      <option value="not-sure">Not sure yet</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-white/70 mb-1.5 block">
                      Timeline
                    </label>
                    <select
                      value={form.timeline}
                      onChange={(e) => update("timeline", e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-purple-500"
                    >
                      <option value="">When do you need this?</option>
                      <option value="asap">As soon as possible</option>
                      <option value="2-4-weeks">2–4 weeks</option>
                      <option value="1-2-months">1–2 months</option>
                      <option value="flexible">Flexible</option>
                    </select>
                  </div>
                  <div className="flex gap-3 mt-2">
                    <button
                      onClick={() => setStep(1)}
                      className="flex-1 py-3 rounded-full border border-white/15 hover:bg-white/5 transition"
                    >
                      Back
                    </button>
                    <button
                      onClick={() => setStep(3)}
                      className="flex-1 py-3 rounded-full bg-purple-600 hover:bg-purple-500 transition font-medium"
                    >
                      Continue
                    </button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-white/70 mb-1.5 block">
                      What do you want built? *
                    </label>
                    <textarea
                      value={form.description}
                      onChange={(e) => update("description", e.target.value)}
                      rows={4}
                      placeholder="Describe the project, features, or problems you want solved..."
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-purple-500 resize-none"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-white/70 mb-1.5 block">
                      Main goals
                    </label>
                    <textarea
                      value={form.goals}
                      onChange={(e) => update("goals", e.target.value)}
                      rows={2}
                      placeholder="More orders, save time, look more professional..."
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-purple-500 resize-none"
                    />
                  </div>
                  <div className="flex gap-3 mt-2">
                    <button
                      onClick={() => setStep(2)}
                      className="flex-1 py-3 rounded-full border border-white/15 hover:bg-white/5 transition"
                    >
                      Back
                    </button>
                    <button
                      onClick={submit}
                      disabled={!form.description || loading}
                      className="flex-1 py-3 rounded-full bg-purple-600 hover:bg-purple-500 disabled:opacity-40 transition font-medium flex items-center justify-center gap-2"
                    >
                      {loading ? (
                        "Sending..."
                      ) : (
                        <>
                          <Send size={16} /> Send Request
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="text-sm text-white/70 mb-1.5 block">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-purple-500 transition"
      />
    </div>
  );
}
