"use client";

import { motion } from "framer-motion";

const services = [
  {
    id: "websites",
    title: "Websites + AI Voice",
    subtitle: "Intelligent sites that speak",
    description:
      "Full-stack websites with bilingual AI voice agents. Customers order, ask questions, and book — hands-free.",
  },
  {
    id: "apps",
    title: "Apps that Save Money",
    subtitle: "Automation that pays for itself",
    description:
      "Custom tools that cut costs, remove busywork, and run your operations while you sleep.",
  },
  {
    id: "commercials",
    title: "Commercial Ads",
    subtitle: "Cinematic content that converts",
    description:
      "High-end video commercials and ads designed for local businesses that want to look bigger than they are.",
  },
];

interface ServiceNodesProps {
  onSelect: (id: string) => void;
}

export default function ServiceNodes({ onSelect }: ServiceNodesProps) {
  return (
    <div className="absolute left-6 md:left-12 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-5 max-w-xs">
      {services.map((s, i) => (
        <motion.button
          key={s.id}
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.8 + i * 0.15, duration: 0.6 }}
          onClick={() => onSelect(s.id)}
          className="group text-left glass rounded-2xl px-5 py-4 hover:border-purple-400/60 transition-all duration-300 hover:scale-[1.03]"
        >
          <div className="text-xs uppercase tracking-[0.2em] text-purple-300/80 mb-1">
            {s.subtitle}
          </div>
          <div className="text-lg font-semibold text-white group-hover:text-purple-200 transition-colors">
            {s.title}
          </div>
          <p className="text-sm text-white/50 mt-1.5 leading-relaxed hidden md:block">
            {s.description}
          </p>
        </motion.button>
      ))}
    </div>
  );
}
