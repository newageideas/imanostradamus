import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        cosmic: "#030014",
        purple: {
          400: "#c084fc",
          500: "#a855f7",
          600: "#9333ea",
          800: "#6b21a8",
          950: "#3b0764",
        },
      },
    },
  },
  plugins: [],
};
export default config;
